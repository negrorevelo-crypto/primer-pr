<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#C5BAAA">
  <meta name="description" content="SumaRitmo te ayuda a entender tu ritmo, escuchar tu cuerpo y mejorar frente a ti mismo, con o sin reloj.">
  <title>SumaRitmo — Tu bienestar, a tu ritmo</title>
  <link rel="preload" href="assets/fonts/archivo-latin.woff2" as="font" type="font/woff2" crossorigin>
  <link rel="stylesheet" href="assets/landing.css?v=20261128-1">
</head>
<body>
  <header class="site-header">
    <a class="brand" href="index.php" aria-label="SumaRitmo, inicio"><span class="brand-mark">∿</span><span>SumaRitmo<span class="brand-dot">.</span></span></a>
    <nav class="desktop-nav" aria-label="Navegación principal">
      <a href="#como-funciona">Cómo funciona</a>
      <a href="#multideporte">Multideporte</a>
      <a href="#bienestar">Bienestar</a>
    </nav>
    <div class="header-actions"><a class="login-link" href="index.php?entrar=1">Iniciar sesión</a><a class="button button-small" href="index.php?crear=1">Probar Nivel 1 <span>↗</span></a></div>
  </header>

  <main>
    <section class="hero" aria-labelledby="hero-title">
      <div class="hero-copy">
        <div class="eyebrow"><span class="eyebrow-dot"></span> DEPORTE · DESCANSO · BIENESTAR</div>
        <h1 id="hero-title">Tu única competencia<br><em>eres tú.</em></h1>
        <p class="hero-intro">Entiende tu ritmo y reconoce cuánto has avanzado desde donde empezaste. Registra tus deportes, descanso y hábitos; puedes escribir los datos del reloj o subir una captura para revisarlos.</p>
        <div class="hero-actions"><a class="button" href="index.php?crear=1">Probar Nivel 1 <span>→</span></a><a class="text-link" href="#como-funciona">Conoce SumaRitmo <span>↓</span></a></div>
        <div class="hero-note"><span class="note-check">✓</span> Acceso piloto sin cobro · Avanza sin rankings ni comparaciones.</div>
      </div>
      <figure class="hero-visual">
        <img src="assets/images/ciclismo-montana.jpg" alt="Ciclista disfrutando un recorrido entre montañas" fetchpriority="high">
        <div class="hero-image-shade"></div>
        <figcaption><span class="photo-kicker">A TU MANERA</span><strong>Lo que haces<br>también suma.</strong><span class="photo-caption">Una sesión a la vez · Un día a la vez</span></figcaption>
        <span class="hero-float"><span class="float-star">✳</span><span><b>Tu ritmo</b><small>Tu propio progreso</small></span></span>
      </figure>
      <div class="hero-bottom"><span>UN SOLO LUGAR PARA</span><div><b>MOVERTE</b><i></i><b>DESCANSAR</b><i></i><b>DISFRUTAR</b></div><span class="hero-bottom-mark">SUMARITMO · 01</span></div>
    </section>

    <section class="intro-section" id="como-funciona">
      <div class="section-heading"><div><div class="eyebrow">MENOS PRESIÓN. MÁS CONEXIÓN.</div><h2>Mejorar empieza<br>por escucharte.</h2></div><p>No buscamos que le ganes a nadie. Queremos ayudarte a entender tu propio punto de partida y a encontrar un ritmo que te acerque, paso a paso, a lo que quieres lograr.</p></div>
      <div class="steps-grid">
        <article class="step-card"><span class="step-number">01</span><div class="step-icon move-icon">↗</div><h3>Muévete como te gusta</h3><p>Registra tus deportes y duración. Si tienes datos en el reloj, puedes escribirlos o subir una captura; revisas los valores antes de guardarlos.</p><span class="step-foot">FÚTBOL · PÁDEL · NATACIÓN · Y MÁS</span></article>
        <article class="step-card"><span class="step-number">02</span><div class="step-icon sleep-icon">☾</div><h3>Escucha lo que necesitas</h3><p>Anota tu descanso, energía y hábitos de alimentación para entender mejor cómo te sientes.</p><span class="step-foot">DESCANSO · COMIDA · BIENESTAR</span></article>
        <article class="step-card"><span class="step-number">03</span><div class="step-icon insight-icon">✳</div><h3>Elige un siguiente paso</h3><p>Si tus registros sugieren que te vendría bien recuperar, bajar el ritmo o retomar poco a poco, te lo explicamos con claridad. También reconocemos tus avances.</p><span class="step-foot">UNA IDEA SENCILLA · CON SU MOTIVO</span></article>
      </div>
    </section>

    <section class="sports-section" id="multideporte">
      <div class="sports-heading"><div><div class="eyebrow">CADA PERSONA TIENE SU CAMINO</div><h2>Tu progreso se mide<br>contigo.</h2></div><p>Compara tus semanas con tu propio punto de partida. La meta es avanzar a tu manera, no alcanzar la marca de otra persona.</p></div>
      <div class="sport-grid">
        <article class="sport-card sport-large"><img src="assets/images/futbol.jpg" alt="Jugador de fútbol en un salto para alcanzar el balón" loading="lazy"><span class="sport-overlay"></span><div class="sport-caption"><small>JUEGA A TU RITMO</small><h3>Fútbol</h3></div></article>
        <article class="sport-card"><img src="assets/images/padel.jpg" alt="Partido de pádel en una cancha azul" loading="lazy"><span class="sport-overlay"></span><div class="sport-caption"><small>UN PUNTO A LA VEZ</small><h3>Pádel</h3></div></article>
        <article class="sport-card"><img src="assets/images/natacion.jpg" alt="Nadador avanzando por una piscina" loading="lazy"><span class="sport-overlay"></span><div class="sport-caption"><small>ENCUENTRA TU CALMA</small><h3>Natación</h3></div></article>
        <article class="sport-card"><img src="assets/images/tenis.jpg" alt="Tenista jugando en una cancha de arcilla" loading="lazy"><span class="sport-overlay"></span><div class="sport-caption"><small>MUÉVETE, RESPONDE</small><h3>Tenis</h3></div></article>
        <article class="sport-card"><img src="assets/images/correr.jpg" alt="Persona corriendo por un sendero al atardecer" loading="lazy"><span class="sport-overlay"></span><div class="sport-caption"><small>UN PASO MÁS</small><h3>Correr</h3></div></article>
        <article class="sport-card"><img src="assets/images/ciclismo-atardecer.jpg" alt="Ciclista recorriendo la carretera al atardecer" loading="lazy"><span class="sport-overlay"></span><div class="sport-caption"><small>SIGUE TU CAMINO</small><h3>Ciclismo</h3></div></article>
        <article class="sport-card"><img src="assets/images/baloncesto.jpg" alt="Amigos jugando baloncesto al aire libre" loading="lazy"><span class="sport-overlay"></span><div class="sport-caption"><small>JUNTOS SE DISFRUTA</small><h3>Baloncesto</h3></div></article>
        <article class="sport-card"><img src="assets/images/senderismo.jpg" alt="Excursionista recorriendo un sendero de montaña" loading="lazy"><span class="sport-overlay"></span><div class="sport-caption"><small>RESPIRA Y EXPLORA</small><h3>Senderismo</h3></div></article>
        <article class="sport-card"><img src="assets/images/fuerza.jpg" alt="Entrenamiento de fuerza con pesas" loading="lazy"><span class="sport-overlay"></span><div class="sport-caption"><small>FUERZA A TU MANERA</small><h3>Entrenamiento</h3></div></article>
      </div>
      <div class="sport-footnote"><span>✳</span> ¿Practicas otra actividad? También puedes registrarla.</div>
    </section>

    <section class="wellbeing-section" id="bienestar">
      <div class="wellbeing-copy"><div class="eyebrow">NO TODO ES ENTRENAR</div><h2>Avanzar también<br>es saber pausar.</h2><p>El progreso no siempre viene de hacer más. Al registrar actividad, descanso y sensaciones, podemos sugerirte cuándo mantener tu ritmo, cuándo suavizarlo y cuándo darte espacio para recuperar.</p><a class="text-link" href="index.php?crear=1">Prueba el Nivel 1 <span>→</span></a></div>
      <div class="wellbeing-visuals">
        <figure class="wellbeing-photo sleep-photo"><img src="assets/images/descanso.jpg" alt="Persona descansando en su cama" loading="lazy"><span class="wellbeing-photo-shade"></span><figcaption><small>DESCANSO</small><strong>Hacer una pausa<br>también suma.</strong></figcaption></figure>
        <figure class="wellbeing-photo food-photo"><img src="assets/images/alimentacion.jpg" alt="Desayuno casero con fruta, cereal y pan" loading="lazy"><span class="wellbeing-photo-shade"></span><figcaption><small>ALIMENTACIÓN</small><strong>Hábitos reales,<br>sin juicios.</strong></figcaption></figure>
      </div>
    </section>

    <section class="food-note-section">
      <div class="food-note-mark">✳</div>
      <div><div class="eyebrow">ALIMENTARTE TAMBIÉN ES ESCUCHARTE</div><h2>Comida real, sin reglas que te alejen de ti.</h2><p>Te invitamos a observar qué comes y cómo te sientes: energía, hambre, saciedad y recuperación. Valoramos alimentos poco procesados, proteína suficiente, grasas presentes en alimentos y carbohidratos elegidos según tu actividad y respuesta personal. Sin contar calorías ni juzgar.</p></div>
    </section>

    <section class="preview-section">
      <div class="preview-copy"><div class="eyebrow">CON RELOJ O SIN RELOJ</div><h2>Datos y sensaciones,<br>en la misma conversación.</h2><p>Durante el piloto, si el reloj todavía no está conectado, puedes subir una captura, revisar los valores y confirmarlos. También puedes escribirlos a mano. Cada sugerencia explica qué señales tomó en cuenta.</p><a class="button" href="index.php?crear=1">Crea tu espacio <span>→</span></a></div>
      <figure class="product-slot"><span class="product-slot-top"><i></i><i></i><i></i><small>SUMARITMO · MI DÍA</small></span><div class="product-shot"><img src="assets/images/captura-app.jpg?v=2" alt="Vista ilustrativa del panel de SumaRitmo con actividad, descanso y registros diarios" loading="lazy"></div><figcaption class="product-shot-caption">Así se ve tu espacio personal en SumaRitmo.</figcaption></figure>
    </section>

    <section class="closing-cta"><div class="closing-spark">✳</div><div class="eyebrow">TU ÚNICA COMPETENCIA ERES TÚ</div><h2>Lo que buscas mejorar<br>empieza contigo.</h2><p>Registra un día, escucha tu cuerpo y encuentra un paso que te acerque a tu propio objetivo.</p><a class="button button-light" href="index.php?crear=1">Probar el Nivel 1 <span>→</span></a><small>Acceso piloto sin cobro. Orientación general; no sustituye atención profesional.</small></section>
  </main>

  <footer class="site-footer"><a class="brand" href="index.php"><span class="brand-mark">∿</span><span>SumaRitmo<span class="brand-dot">.</span></span></a><p>Lo que haces a tu ritmo, suma.</p><div><span>Espacio para personas adultas (18+).</span><a href="privacy.php">Política de datos</a><a href="index.php?entrar=1">Iniciar sesión</a><span>Orientación general; no sustituye consejo profesional.</span></div></footer>
  <script src="assets/login-feedback.js?v=20261122-2" defer></script>
</body>
</html>
