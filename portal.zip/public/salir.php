<?php
require dirname(__DIR__) . '/app/bootstrap.php';
if (usuario()) auditar('logout');
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();
header('Location: ' . url('login.php'));
